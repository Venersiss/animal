/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Venersis
 */
public class DBConnection2 {
    private static Connection Myconnection;
    
    public static void init() {
    try{ 
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Myconnection=DriverManager.getConnection("jdbc:mysql://localhost:3306/animal","root", "arcadegames123");
       
    }
   
    catch(ClassNotFoundException | SQLException e){}
    }
    
    public static Connection getConnection(){
        return Myconnection; }
    
    public static void close(ResultSet rs){
    
         if(rs!=null){
         try{
             rs.close();
        }
         catch(SQLException e){System.out.println(e);}
         
         }
    }
    
    public void Destroy(){
    if(Myconnection!=null){
     
        try{
        Myconnection.close();
        }
        catch(SQLException e){}
    
    }
  
}
}
